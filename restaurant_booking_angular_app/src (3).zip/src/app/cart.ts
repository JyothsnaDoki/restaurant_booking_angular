export interface Cart {
    cId : number;
    quantity: String;
    cancelOrder:String;
    placeOrder:String;
}

