
export interface Feed
{ 
    feedId:number;

    Text:string;
    Rating:number;

}