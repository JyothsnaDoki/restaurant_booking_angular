export interface User {
    userId: number;
    userName: string;
    email: string;
    password: string;
    confirmPassword: string;
    contact:string;
    userType: string;
}
