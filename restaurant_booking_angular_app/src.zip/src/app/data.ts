export interface Data {
    itemId:number;
    itemName:String;
    description:String;
    price:number;
    image:String;
    itemAvailability:String;
}
